package model;

public class Jornal extends ItemBiblioteca {
    private String dataPublicacao;

    public Jornal(int id, String titulo, String dataPublicacao) {
        super(id, titulo);
        this.dataPublicacao = dataPublicacao;
    }

    public String getDataPublicacao() { return dataPublicacao; }
}
