package model;

import java.util.Date;

public class Emprestimo {
    private int id;
    private Usuario usuario;
    private ItemBiblioteca item;
    private Date dataEmprestimo;

    public Emprestimo(int id, Usuario usuario, ItemBiblioteca item, Date dataEmprestimo) {
        this.id = id;
        this.usuario = usuario;
        this.item = item;
        this.dataEmprestimo = dataEmprestimo;
    }

    public int getId() { return id; }
    public Usuario getUsuario() { return usuario; }
    public ItemBiblioteca getItem() { return item; }
    public Date getDataEmprestimo() { return dataEmprestimo; }
}
