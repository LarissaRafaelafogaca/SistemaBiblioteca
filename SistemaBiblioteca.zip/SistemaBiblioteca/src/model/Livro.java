package model;

public class Livro extends ItemBiblioteca {
    private String autor;
    private String editora;
    private String isbn;

    public Livro(int id, String titulo, String autor, String editora, String isbn) {
        super(id, titulo);
        this.autor = autor;
        this.editora = editora;
        this.isbn = isbn;
    }

    public String getAutor() {
        return autor;
    }

    public String getEditora() {
        return editora;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void exibirDetalhes() {
        System.out.println("Livro:");
        System.out.println("ID: " + getId());
        System.out.println("Título: " + getTitulo());
        System.out.println("Autor: " + autor);
        System.out.println("Editora: " + editora);
        System.out.println("ISBN: " + isbn);
        System.out.println();
    }
}