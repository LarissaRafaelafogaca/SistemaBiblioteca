package main;

import model.*;
import dao.*;
import java.util.*;

public class SistemaBiblioteca {
    public static void main(String[] args) {
        LivroDAO livroDAO = new LivroDAO();
        JornalDAO jornalDAO = new JornalDAO();
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        EmprestimoDAO emprestimoDAO = new EmprestimoDAO();

        Scanner sc = new Scanner(System.in);
        int opcao = -1;

        do {
            try {
                System.out.println("\n1 - Cadastrar Livro");
                System.out.println("2 - Cadastrar Jornal");
                System.out.println("3 - Cadastrar Usuário");
                System.out.println("4 - Realizar Empréstimo");
                System.out.println("5 - Listar Livros");
                System.out.println("6 - Listar Jornais");
                System.out.println("7 - Listar Usuários");
                System.out.println("8 - Listar Empréstimos");
                System.out.println("0 - Sair");
                System.out.print("Escolha: ");
                opcao = sc.nextInt();
                sc.nextLine(); // Limpa buffer do scanner após nextInt()

                switch (opcao) {
                    case 1:
                        System.out.print("ID: ");
                        int idL = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Título: ");
                        String tituloL = sc.nextLine();
                        System.out.print("Autor: ");
                        String autor = sc.nextLine();
                        System.out.print("Editora: ");
                        String editora = sc.nextLine();
                        System.out.print("ISBN: ");
                        String isbn = sc.nextLine();
                        livroDAO.adicionar(new Livro(idL, tituloL, autor, editora, isbn));
                        System.out.println("Livro cadastrado com sucesso!");
                        break;

                    case 2:
                        System.out.print("ID: ");
                        int idJ = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Título: ");
                        String tituloJ = sc.nextLine();
                        System.out.print("Data de Publicação: ");
                        String dataPub = sc.nextLine();
                        jornalDAO.adicionar(new Jornal(idJ, tituloJ, dataPub));
                        System.out.println("Jornal cadastrado com sucesso!");
                        break;

                    case 3:
                        System.out.print("ID: ");
                        int idU = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Nome: ");
                        String nome = sc.nextLine();
                        usuarioDAO.adicionar(new Usuario(idU, nome));
                        System.out.println("Usuário cadastrado com sucesso!");
                        break;

                    case 4:
                        System.out.print("ID do Empréstimo: ");
                        int idE = sc.nextInt();
                        System.out.print("ID do Usuário: ");
                        int idUsuario = sc.nextInt();
                        System.out.print("ID do Item (Livro ou Jornal): ");
                        int idItem = sc.nextInt();
                        sc.nextLine();

                        Usuario usuario = usuarioDAO.buscarPorId(idUsuario);
                        ItemBiblioteca item = livroDAO.buscarPorId(idItem);
                        if (item == null) item = jornalDAO.buscarPorId(idItem);

                        if (usuario != null && item != null && !item.isEmprestado()) {
                            item.setEmprestado(true);
                            emprestimoDAO.adicionar(new Emprestimo(idE, usuario, item, new Date()));
                            System.out.println("Empréstimo realizado com sucesso!");
                        } else {
                            System.out.println("Erro: usuário ou item inválido, ou item já emprestado.");
                        }
                        break;

                    case 5:
                        System.out.println("=== Lista de Livros ===");
                        for (Livro l : livroDAO.listar())
                            System.out.println(l.getId() + ": " + l.getTitulo() + " - " + l.getAutor());
                        break;

                    case 6:
                        System.out.println("=== Lista de Jornais ===");
                        for (Jornal j : jornalDAO.listar())
                            System.out.println(j.getId() + ": " + j.getTitulo() + " - " + j.getDataPublicacao());
                        break;

                    case 7:
                        System.out.println("=== Lista de Usuários ===");
                        for (Usuario u : usuarioDAO.listar())
                            System.out.println(u.getId() + ": " + u.getNome());
                        break;

                    case 8:
                        System.out.println("=== Lista de Empréstimos ===");
                        for (Emprestimo e : emprestimoDAO.listar())
                            System.out.println(e.getId() + ": " + e.getUsuario().getNome() + " emprestou " + e.getItem().getTitulo());
                        break;

                    case 0:
                        System.out.println("Saindo...");
                        break;

                    default:
                        System.out.println("Opção inválida.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Informação inválida, tente novamente.");
                sc.nextLine(); // Limpa o buffer do scanner
            } catch (Exception e) {
                System.out.println("Ocorreu um erro: " + e.getMessage());
            }
        } while (opcao != 0);

        sc.close();
    }
}