package dao;

import model.Livro;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivroDAO {

    // Adiciona um novo livro ao banco de dados
    public void adicionar(Livro livro) {
        String sql = "INSERT INTO livro (titulo, autor, editora, isbn) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, livro.getTitulo());
            stmt.setString(2, livro.getAutor());
            stmt.setString(3, livro.getEditora());
            stmt.setString(4, livro.getIsbn());

            stmt.executeUpdate();
            System.out.println("✅ Livro cadastrado com sucesso!");

        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("❌ Erro: este livro já existe ou viola uma restrição de chave única.");
        } catch (SQLDataException e) {
            System.out.println("❌ Dados inválidos. Verifique os campos e tente novamente.");
        } catch (SQLException e) {
            System.out.println("❌ Erro ao cadastrar livro: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("❌ Erro inesperado: " + e.getMessage());
        }
    }

    // Lista todos os livros cadastrados
    public List<Livro> listar() {
        List<Livro> livros = new ArrayList<>();
        String sql = "SELECT * FROM livro";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Livro livro = new Livro(
                    rs.getInt("id"),
                    rs.getString("titulo"),
                    rs.getString("autor"),
                    rs.getString("editora"),
                    rs.getString("isbn")
                );
                livros.add(livro);
            }

        } catch (SQLException e) {
            System.out.println("❌ Erro ao listar livros: " + e.getMessage());
        }

        return livros;
    }

    // Busca um livro pelo ID
    public Livro buscarPorId(int id) {
        String sql = "SELECT * FROM livro WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Livro(
                    rs.getInt("id"),
                    rs.getString("titulo"),
                    rs.getString("autor"),
                    rs.getString("editora"),
                    rs.getString("isbn")
                );
            }

        } catch (SQLException e) {
            System.out.println("❌ Erro ao buscar livro: " + e.getMessage());
        }

        return null;
    }

    // Remove um livro pelo ID
    public void remover(int id) {
        String sql = "DELETE FROM livro WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("✅ Livro removido com sucesso.");
            } else {
                System.out.println("⚠️ Nenhum livro encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.out.println("❌ Erro ao remover livro: " + e.getMessage());
        }
    }

    // Atualiza os dados de um livro
    public void atualizar(Livro livro) {
        String sql = "UPDATE livro SET titulo = ?, autor = ?, editora = ?, isbn = ? WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, livro.getTitulo());
            stmt.setString(2, livro.getAutor());
            stmt.setString(3, livro.getEditora());
            stmt.setString(4, livro.getIsbn());
            stmt.setInt(5, livro.getId());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("✅ Livro atualizado com sucesso.");
            } else {
                System.out.println("⚠️ Nenhum livro encontrado com o ID informado.");
            }

        } catch (SQLException e) {
            System.out.println("❌ Erro ao atualizar livro: " + e.getMessage());
        }
    }
}
