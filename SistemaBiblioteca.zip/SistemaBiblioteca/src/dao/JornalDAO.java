package dao;

import model.Jornal;

import java.util.ArrayList;
import java.util.List;

public class JornalDAO {
    private List<Jornal> jornais = new ArrayList<>();

    public void adicionar(Jornal jornal) { jornais.add(jornal); }
    public List<Jornal> listar() { return jornais; }
    public Jornal buscarPorId(int id) {
        for (Jornal j : jornais) {
            if (j.getId() == id) return j;
        }
        return null;
    }
}
