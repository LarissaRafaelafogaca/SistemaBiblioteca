-- Tabela de usuários
CREATE TABLE usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

-- Tabela de itens da biblioteca (superclasse genérica)
CREATE TABLE livro (
    id INT PRIMARY KEY,
    titulo VARCHAR(100),
    autor VARCHAR(100),
    editora VARCHAR(100),
    isbn VARCHAR(20)
);
);

-- Tabela de livros (herda de item_biblioteca)
CREATE TABLE livro (
    id INT AUTO_INCREMENT PRIMARY KEY,
    autor VARCHAR(100) NOT NULL,
    isbn VARCHAR(20) UNIQUE,
    FOREIGN KEY (id) REFERENCES item_biblioteca(id) ON DELETE CASCADE
);

-- Tabela de jornais (herda de item_biblioteca)
CREATE TABLE jornal (
    id INT PRIMARY KEY,
    editora VARCHAR(100),
    data_publicacao DATE,
    FOREIGN KEY (id) REFERENCES item_biblioteca(id) ON DELETE CASCADE
);

-- Tabela de empréstimos
CREATE TABLE emprestimo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    id_item INT,
    data_emprestimo DATE NOT NULL,
    data_devolucao DATE,
    devolvido BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id),
    FOREIGN KEY (id_item) REFERENCES item_biblioteca(id)
);